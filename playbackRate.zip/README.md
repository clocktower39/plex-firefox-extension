# plex-firefox-extension

### Features

- Adjust the playback speed of media

### In Development
    
- Automatically skip intro on plex prompt (plex pass required)
- Imediate skip to next episode on plex prompt

### Installation

You must use the nightly or developer build of firefox.
Download this repository as a ZIP.

PROCEED WITH CATION: Changing advanced configuration preferences can impact Firefox Developer Edition performance or security.

Enter `about:config` in the address bar, then `Accept the Rick and Continue`
Search for `xpinstall.signatures.required` and set it to `false`

Enter `about:addons` in the address bar
Click the settings icon next to Manage you Extensions, then `Install Add-on From File...`
Select the downloaded ZIP of the repository and enjoy.
